#ifndef __EXTI__H
#define __EXTI__H
#include "main.h"

#ifdef __cplusplus
extern "C"
{
#endif
  typedef uint8_t Button;
  extern Button key1, key2, key3;
#ifdef __cplusplus
}
#endif

#endif