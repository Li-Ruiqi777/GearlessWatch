#ifndef __LCD_INIT_H
#define __LCD_INIT_H

//#include "sys.h"
/*
#define unsigned char unsigned char
#define unsigned int unsigned int
#define unsigned long unsigned long
*/

#define USE_HORIZONTAL 0 //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����
#define Chip_Selection 1 //����оƬ��ʼ�� 0ΪILI9341  1ΪST7789

#if USE_HORIZONTAL == 0 || USE_HORIZONTAL == 1
#define LCD_W 240
#define LCD_H 280

#else
#define LCD_W 280
#define LCD_H 240
#endif

//-----------------LCD�˿ڶ���----------------

//#define LCD_SCLK_Clr() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12, GPIO_PIN_RESET)//SCL=SCLK
//#define LCD_SCLK_Set() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12, GPIO_PIN_SET)

//#define LCD_MOSI_Clr() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13, GPIO_PIN_RESET)//SDA=MOSI
//#define LCD_MOSI_Set() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13, GPIO_PIN_SET)

#define LCD_RES_Clr() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET) // RES
#define LCD_RES_Set() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET)

#define LCD_DC_Clr() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET) // DC
#define LCD_DC_Set() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET)

#define LCD_CS_Clr() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET) // CS
#define LCD_CS_Set() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET)

#define LCD_BLK_Clr() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET) // BLK
#define LCD_BLK_Set() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET)

void LCD_GPIO_Init(void);                                                                 //��ʼ��GPIO
void LCD_Writ_Bus(unsigned char dat);                                                     //ģ��SPIʱ��
void LCD_WR_DATA8(unsigned char dat);                                                     //д��һ���ֽ�
void LCD_WR_DATA(unsigned int dat);                                                       //д�������ֽ�
void LCD_WR_REG(unsigned char dat);                                                       //д��һ��ָ��
void LCD_Address_Set(unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2); //�������꺯��
void LCD_Init(void);                                                                      // LCD��ʼ��
#endif
