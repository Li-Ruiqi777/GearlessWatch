// #include "main.h"
// #include "CST816.h"
// #include "math.h"
// #include "i2c.h"

// CST816_Info CST816_Instance; //����CST816ʵ����

// void CST816_IIC_Start(void)
// {
// 	GPIO_InitTypeDef GPIO_InitStruct = {0};

// 	CST816_SDA_OUT();
// 	CST816_SDA_Set();
// 	CST816_SCL_Set();
// 	HAL_Delay(4);
// 	CST816_SDA_Clr();
// 	HAL_Delay(4);
// 	CST816_SCL_Clr();
// }

// void CST816_IIC_Stop(void)
// {
// 	GPIO_InitTypeDef GPIO_InitStruct = {0};
// 	CST816_SDA_OUT();

// 	CST816_SCL_Clr();
// 	CST816_SDA_Clr();
// 	HAL_Delay(4);
// 	CST816_SCL_Set();
// 	CST816_SDA_Set();
// 	HAL_Delay(4);
// }

// void CST816_IIC_ACK(void)
// {
// 	GPIO_InitTypeDef GPIO_InitStruct = {0};
// 	CST816_SDA_OUT();

// 	CST816_SCL_Clr();
// 	//	HAL_Delay(4);				//jia
// 	CST816_SDA_Clr();
// 	HAL_Delay(2);
// 	CST816_SCL_Set();
// 	HAL_Delay(2);
// 	CST816_SCL_Clr();
// }
// void CST816_IIC_NACK(void)
// {
// 	GPIO_InitTypeDef GPIO_InitStruct = {0};
// 	CST816_SDA_OUT();
// 	CST816_SCL_Clr();

// 	CST816_SDA_Set();
// 	HAL_Delay(2);
// 	CST816_SCL_Set();
// 	HAL_Delay(2);
// 	CST816_SCL_Clr();
// }

// uint8_t CST816_IIC_Wait_ACK(void)
// {
// 	GPIO_InitTypeDef GPIO_InitStruct = {0};
// 	uint8_t t = 0;

// 	CST816_SDA_IN();
// 	CST816_SDA_Set();
// 	HAL_Delay(1);
// 	CST816_SCL_Set();
// 	HAL_Delay(1);
// 	while (CST816_SDA_Get())
// 	{
// 		t++;
// 		if (t > 250)
// 		{
// 			CST816_IIC_Stop();
// 			return 1;
// 		}
// 	}
// 	CST816_SCL_Clr();
// 	return 0;
// }

// void CST816_IIC_SendByte(uint8_t byte)
// {
// 	GPIO_InitTypeDef GPIO_InitStruct = {0};
// 	uint8_t BitCnt;
// 	CST816_SDA_OUT();
// 	CST816_SCL_Clr();
// 	for (BitCnt = 0; BitCnt < 8; BitCnt++) //Ҫ���͵����ݳ���Ϊ8λ
// 	{
// 		//		HAL_Delay(5);
// 		if (byte & 0x80)
// 			CST816_SDA_Set(); //�жϷ���λ
// 		else
// 			CST816_SDA_Clr();
// 		byte <<= 1;
// 		HAL_Delay(2);
// 		CST816_SCL_Set();
// 		HAL_Delay(2);
// 		CST816_SCL_Clr();
// 		HAL_Delay(2);
// 	}
// }

// uint8_t CST816_IIC_RecvByte(void)
// {
// 	GPIO_InitTypeDef GPIO_InitStruct = {0};
// 	uint8_t retc;
// 	uint8_t BitCnt;
// 	retc = 0;
// 	CST816_SDA_IN(); //��������Ϊ���뷽ʽ
// 	for (BitCnt = 0; BitCnt < 8; BitCnt++)
// 	{
// 		CST816_SCL_Clr();
// 		HAL_Delay(2);
// 		CST816_SCL_Set(); //��ʱ����Ϊ��ʹ��������������Ч
// 		retc = retc << 1;
// 		if (CST816_SDA_Get())
// 			retc++; //������λ,���յ�����λ����retc��
// 		HAL_Delay(1);
// 	}
// 	return (retc);
// }

// void CST816_IIC_WriteREG(uint8_t reg, uint8_t date)
// {
// 	// CST816_IIC_Start();
// 	// CST816_IIC_SendByte(0x2A);
// 	// CST816_IIC_Wait_ACK();
// 	// CST816_IIC_SendByte(reg);
// 	// CST816_IIC_Wait_ACK();
// 	// CST816_IIC_SendByte(date);
// 	// CST816_IIC_Wait_ACK();
// 	// CST816_IIC_Stop();
// 	// HAL_Delay(10);

// 	HAL_I2C_Mem_Write(&hi2c1, CST816_ADDR << 1, reg, I2C_MEMADD_SIZE_8BIT, &date, 1, 100);
// }

// uint8_t CST816_IIC_ReadREG(uint8_t reg)
// {
// 	uint8_t date;
// 	// CST816_IIC_Start();
// 	// CST816_IIC_SendByte(0x2A);
// 	// CST816_IIC_Wait_ACK();
// 	// CST816_IIC_SendByte(reg);
// 	// CST816_IIC_Wait_ACK();
// 	// CST816_IIC_Start();
// 	// //	HAL_Delay(4);
// 	// CST816_IIC_SendByte(0x2B);
// 	// CST816_IIC_Wait_ACK();
// 	// date = CST816_IIC_RecvByte();
// 	// CST816_IIC_ACK();
// 	// CST816_IIC_Stop();
// 	// //	HAL_Delay(5);
// 	// return date;

// 	HAL_I2C_Mem_Read(&hi2c1, CST816_ADDR << 1, reg, I2C_MEMADD_SIZE_8BIT, &date, 1, 100);
// 	return date;
// }

// void CST816_Init(void)
// {
// }

// uint8_t CST816_Get_ChipID()
// {
// 	return CST816_IIC_ReadREG(ChipID);
// }

// void CST816_Get_XY()
// {
// 	uint8_t temp[4];
// 	unsigned int x, y;

// 	CST816_IIC_Start();
// 	CST816_IIC_SendByte(0x2A);
// 	CST816_IIC_Wait_ACK();
// 	CST816_IIC_SendByte(0x03);
// 	CST816_IIC_Wait_ACK();
// 	CST816_IIC_Start();
// 	//	HAL_Delay(4);
// 	CST816_IIC_SendByte(0x2B);
// 	CST816_IIC_Wait_ACK();
// 	temp[0] = CST816_IIC_RecvByte();
// 	CST816_IIC_ACK();
// 	temp[1] = CST816_IIC_RecvByte();
// 	CST816_IIC_ACK();
// 	temp[2] = CST816_IIC_RecvByte();
// 	CST816_IIC_ACK();
// 	temp[3] = CST816_IIC_RecvByte();
// 	CST816_IIC_ACK();
// 	CST816_IIC_Stop();

// 	x = (unsigned int)((temp[0] & 0x0F) << 8) | temp[1]; //(temp[0]&0X0F)<<4|
// 	y = (unsigned int)((temp[2] & 0x0F) << 8) | temp[3]; //(temp[2]&0X0F)<<4|
// 	if (x < 240 && y < 280)
// 	{
// 		CST816_Instance.X_Pos = x;
// 		CST816_Instance.Y_Pos = y;
// 	}
// }

// uint8_t CST816_Get_Sta()
// {
// 	uint8_t sta;

// 	CST816_IIC_Start();
// 	CST816_IIC_SendByte(0x2A);
// 	CST816_IIC_Wait_ACK();
// 	CST816_IIC_SendByte(0x01);
// 	CST816_IIC_Wait_ACK();
// 	CST816_IIC_Start();
// 	//	HAL_Delay(4);
// 	CST816_IIC_SendByte(0x2B);
// 	CST816_IIC_Wait_ACK();
// 	CST816_IIC_RecvByte();
// 	CST816_IIC_ACK();
// 	sta = CST816_IIC_RecvByte();
// 	CST816_IIC_ACK();
// 	CST816_IIC_Stop();
// 	//	LCD_ShowIntNum(80,200,sta,5,BLACK,WHITE,16);
// 	if (sta != 255 & sta != 0)
// 		return 1;
// 	else
// 		return 0;
// 	//	return CST816_IIC_ReadREG(FingerNum);
// }

// void CST816_Set_MotionMask(uint8_t Motion)
// {
// 	CST816_IIC_WriteREG(MotionMask, Motion);
// }

// void CST816_Set_IrqCtrl(uint8_t IRQCtrl)
// {
// 	CST816_IIC_WriteREG(IrqCrl, IRQCtrl);
// }

// void CST816_Set_AutoSleep(uint8_t en) //�Ƿ�ʹ���Զ�����͹���ģʽ
// {
// 	if (en == FALSE)
// 	{
// 		CST816_IIC_WriteREG(DisAutoSleep, FALSE);
// 	}
// 	else
// 	{
// 		CST816_IIC_WriteREG(DisAutoSleep, ENABLE);
// 		CST816_IIC_WriteREG(AutoSleepTime, en);
// 	}
// }
// void CST816_Set_AutoRST(uint8_t time) //���ö೤ʱ���޴����Զ���λ��Ĭ��5s,д0����ù���
// {
// 	CST816_IIC_WriteREG(AutoReset, time);
// }
// void CST816_Set_LongPressRST(uint8_t time) //���ó����೤ʱ�临λ��Ĭ��Ϊ10s��д0���ù���
// {
// 	CST816_IIC_WriteREG(LongPressTime, time);
// }
