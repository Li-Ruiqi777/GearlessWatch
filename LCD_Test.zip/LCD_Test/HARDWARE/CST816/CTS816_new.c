#include "main.h"
#include "CST816.h"
#include "math.h"
#include "i2c.h"

CST816_Info CST816_Instance; //创建CST816实例。

void CST816_IIC_WriteREG(uint8_t reg, uint8_t date)
{
  HAL_I2C_Mem_Write(&hi2c1, CST816_ADDR << 1, reg, I2C_MEMADD_SIZE_8BIT, &date, 1, 100);
}

uint8_t CST816_IIC_ReadREG(uint8_t reg)
{
  uint8_t date;
  HAL_I2C_Mem_Read(&hi2c1, CST816_ADDR << 1, reg, I2C_MEMADD_SIZE_8BIT, &date, 1, 100);
  return date;
}

void CST816_Init(void) {}

/**
 * @brief I2C连续读4字节，获得当前触摸位置
 */
void CST816_Get_XY()
{
  uint8_t temp[4];
  uint16_t x, y;
  HAL_I2C_Mem_Read(&hi2c1, CST816_ADDR << 1, XposH, I2C_MEMADD_SIZE_8BIT, temp, 4, 100);
  x = (uint16_t)((temp[0] & 0x0F) << 8) | temp[1];
  y = (uint16_t)((temp[2] & 0x0F) << 8) | temp[3];
  if (x < 240 && y < 280)
  {
    CST816_Instance.X_Pos = x;
    CST816_Instance.Y_Pos = y;
  }
}

/**
 * @brief 连读16bit，得到手势+是否被触摸
 * @return
 */
uint8_t CST816_Get_Sta()
{
  uint8_t temp[2];
  HAL_I2C_Mem_Read(&hi2c1, CST816_ADDR << 1, GestureID, I2C_MEMADD_SIZE_8BIT, temp, 2, 100);
  if (temp[1] == 255)
  {
    CST816_Instance.Down = 1;
    return 1;
  }
  else
  {
    CST816_Instance.Down = 0;
    return 0;
  }
}

/**
 * @brief 使能一些其他触摸方式
 * @param Motion bit0:双击,bit1:使能连续上下滑动,bit2:使能连续左右滑动
 */
void CST816_Set_MotionMask(uint8_t Motion)
{
  HAL_I2C_Mem_Write(&hi2c1, CST816_ADDR << 1, MotionMask, I2C_MEMADD_SIZE_8BIT, &Motion, 1, 100);
}

/**
 * @brief 触摸时发出的脉冲设置
 * @param IRQCtrl
 */
void CST816_Set_IrqCtrl(uint8_t IRQCtrl)
{
  HAL_I2C_Mem_Write(&hi2c1, CST816_ADDR << 1, IrqCrl, I2C_MEMADD_SIZE_8BIT, &IRQCtrl, 1, 100);
}

/**
 * @brief 是否使能自动进入低功耗模式
 * @param en
 */
void CST816_Set_AutoSleep(uint8_t en)
{
  if (en == FALSE)
  {
    CST816_IIC_WriteREG(DisAutoSleep, FALSE);
  }
  else
  {
    CST816_IIC_WriteREG(DisAutoSleep, ENABLE);
    CST816_IIC_WriteREG(AutoSleepTime, en);
  }
}

/**
 * @brief 设置多长时间无触摸自动复位
 * @param time 默认5s,写0则禁用功能
 */
void CST816_Set_AutoRST(uint8_t time)
{
  CST816_IIC_WriteREG(AutoReset, time);
}

/**
 * @brief 设置长按多长时间复位
 * @param time 默认为10s，写0禁用功能
 */
void CST816_Set_LongPressRST(uint8_t time)
{
  CST816_IIC_WriteREG(LongPressTime, time);
}

uint8_t CST816_Get_ChipID()
{
  return CST816_IIC_ReadREG(ChipID);
}
